﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp3
{

	public partial class Window1 : Window
	{
		public Window1()
		{
			InitializeComponent();
			GameSetUp();
		}
		private void CanvasKeyDown(object sender, KeyEventArgs e)
		{





		}
		private void GameSetUp()
		{



			ImageBrush pacmanImage = new ImageBrush();
			pacmanImage.ImageSource = new BitmapImage(new Uri("C:/Users/Надя Мерезок/source/repos/WpfApp3/WpfApp3/Images/pacman.jpg"));
			pacman.Fill = pacmanImage;



			ImageBrush redGhost = new ImageBrush();
			redGhost.ImageSource = new BitmapImage(new Uri("C:/Users/Надя Мерезок/source/repos/WpfApp3/WpfApp3/Images/red.jpg"));
			redGuy.Fill = redGhost;



			ImageBrush orangeGhost = new ImageBrush();
			orangeGhost.ImageSource = new BitmapImage(new Uri("C:/Users/Надя Мерезок/source/repos/WpfApp3/WpfApp3/Images/orange.jpg"));
			orangeGuy.Fill = orangeGhost;



			ImageBrush pinkGhost = new ImageBrush();
			pinkGhost.ImageSource = new BitmapImage(new Uri("C:/Users/Надя Мерезок/source/repos/WpfApp3/WpfApp3/Images/pink.jpg"));
			pinkGuy.Fill = pinkGhost;




		}



		private void Button_Click(object sender, RoutedEventArgs e)
		{
			string messageBoxText = "Are you sure?";
			string caption = "Word Processor";
			MessageBoxButton button = MessageBoxButton.YesNoCancel;
			MessageBoxImage icon = MessageBoxImage.Warning;
			MessageBoxResult result = MessageBox.Show(messageBoxText, caption, button, icon);



			// Process message box results
			switch (result)
			{
				case MessageBoxResult.Yes:
					// User pressed Yes button
					System.Windows.Application.Current.Shutdown();
					break;
				case MessageBoxResult.No:
					// User pressed No button
					// ...
					break;
				case MessageBoxResult.Cancel:
					// User pressed Cancel button
					// ...
					break;
			}
		}
	}
}

